"use strict";

// ---------------------------------------------------------------------------
// Stack (Pilha)
// ---------------------------------------------------------------------------

// Construtor da pilha
function Stack() {
  this.stack = [];
  this.size = 0;
}

// Interface de acesso
Stack.prototype = {

  // verifica se pilha vazia
  empty: function () {
    return (this.size === 0);
  },

  // empilha elemento
  push: function (elem) {
    this.stack.push(elem);
    this.size += 1;
  },

  // desempilha elemento
  pop: function () {
    if (!this.empty()) {
      this.size -= 1;
      return this.stack.pop();
    }
  }
};


// ---------------------------------------------------------------------------
// Queue (Fila)
// ---------------------------------------------------------------------------

// Construtor da fila
function Queue() {
  this.queue = [];
  this.size = 0;
}

// Interface de acesso
Queue.prototype = {

  // verifica se fila vazia
  empty: function () {
    return (this.size === 0);
  },

  // coloca elemento no fim da fila
  put: function (elem) {
    this.queue.push(elem);
    this.size += 1;
  },

  // recupera primeiro elemento da fila
  get: function () {
    if (!this.empty()) {
      this.size -= 1;
      return this.queue.shift();
    }
  }
};


// ---------------------------------------------------------------------------
// Priority Queue (Fila de Prioridades)
// ---------------------------------------------------------------------------

// Construtor da fila de prioridade: 
// a função scoreFunction passada por referência deve retornar 
// um valor numérico para cada elemento da fila;
// esse valor é utilizado internamente para ordernar os elementos da fila.
function PQueue(scoreFunction) {
  this.heap = new BinaryHeap(scoreFunction);
}

// Interface de acesso
PQueue.prototype = {

  // verifica se fila de prioridade está vazia
  empty: function () {
    return (this.heap.size() === 0);
  },

  // coloca elemento no fim da fila
  put: function (elem) {
    this.heap.push(elem);
  },

  // recupera primeiro elemento da fila de acordo 
  // com valor númerico do elemento dado por scoreFunction
  get: function () {
    if (!this.empty()) {
      return this.heap.pop();
    }
  }
};


// ---------------------------------------------------------------------------
// Set (Conjunto)
// ---------------------------------------------------------------------------

// Construtor de conjunto de elementos
// cada elemento é indexado de acordo com o valor de toString()
function Set() {
  this.set = {};
  this.size = 0;
}

// Interface de acesso
Set.prototype = {

  // verifica se conjunto está vazio
  empty: function () {
    return (this.size === 0);
  },

  // verifica se elem está no conjunto
  hasElement: function (elem) {
    return (this.set[elem.toString()] === true);
  },

  // adiciona elem ao conjunto
  add: function (elem) {
    if (!this.hasElement(elem)) {
      this.set[elem.toString()] = true;
      this.size += 1;
    }
  },

  // remove elem do conjunto
  remove: function (elem) {
    if (this.hasElement(elem)) {
      delete this.set[elem.toString()];
      this.size -= 1;
    }
  }
};


// ---------------------------------------------------------------------------
// Outras estruturas de dados auxiliares...
// ---------------------------------------------------------------------------

// Eloquent JavaScript - A Modern Introduction to Programming
// by Marijn Haverbeke
// Appendix 2: Binary Heaps
// http://eloquentjavascript.net/1st_edition/appendix2.html

function BinaryHeap(scoreFunction){
  this.content = [];
  this.scoreFunction = scoreFunction;
}

BinaryHeap.prototype = {
  push: function(element) {
    // Add the new element to the end of the array.
    this.content.push(element);
    // Allow it to bubble up.
    this.bubbleUp(this.content.length - 1);
  },

  pop: function() {
    // Store the first element so we can return it later.
    var result = this.content[0];
    // Get the element at the end of the array.
    var end = this.content.pop();
    // If there are any elements left, put the end element at the
    // start, and let it sink down.
    if (this.content.length > 0) {
      this.content[0] = end;
      this.sinkDown(0);
    }
    return result;
  },

  remove: function(node) {
    var length = this.content.length;
    // To remove a value, we must search through the array to find
    // it.
    for (var i = 0; i < length; i++) {
      if (this.content[i] != node) continue;
      // When it is found, the process seen in 'pop' is repeated
      // to fill up the hole.
      var end = this.content.pop();
      // If the element we popped was the one we needed to remove,
      // we're done.
      if (i == length - 1) break;
      // Otherwise, we replace the removed element with the popped
      // one, and allow it to float up or sink down as appropriate.
      this.content[i] = end;
      this.bubbleUp(i);
      this.sinkDown(i);
      break;
    }
  },

  size: function() {
    return this.content.length;
  },

  bubbleUp: function(n) {
    // Fetch the element that has to be moved.
    var element = this.content[n], score = this.scoreFunction(element);
    // When at 0, an element can not go up any further.
    while (n > 0) {
      // Compute the parent element's index, and fetch it.
      var parentN = Math.floor((n + 1) / 2) - 1,
      parent = this.content[parentN];
      // If the parent has a lesser score, things are in order and we
      // are done.
      if (score >= this.scoreFunction(parent))
        break;

      // Otherwise, swap the parent with the current element and
      // continue.
      this.content[parentN] = element;
      this.content[n] = parent;
      n = parentN;
    }
  },

  sinkDown: function(n) {
    // Look up the target element and its score.
    var length = this.content.length,
    element = this.content[n],
    elemScore = this.scoreFunction(element);

    while(true) {
      // Compute the indices of the child elements.
      var child2N = (n + 1) * 2, child1N = child2N - 1;
      // This is used to store the new position of the element,
      // if any.
      var swap = null;
      // If the first child exists (is inside the array)...
      if (child1N < length) {
        // Look it up and compute its score.
        var child1 = this.content[child1N],
        child1Score = this.scoreFunction(child1);
        // If the score is less than our element's, we need to swap.
        if (child1Score < elemScore)
          swap = child1N;
      }
      // Do the same checks for the other child.
      if (child2N < length) {
        var child2 = this.content[child2N],
        child2Score = this.scoreFunction(child2);
        if (child2Score < (swap == null ? elemScore : child1Score))
          swap = child2N;
      }

      // No need to swap further, we are done.
      if (swap == null) break;

      // Otherwise, swap and continue.
      this.content[n] = this.content[swap];
      this.content[swap] = element;
      n = swap;
    }
  }
};
